import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const EduvoraApp());
}

class EduvoraApp extends StatelessWidget {
  const EduvoraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Eduvora',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF4F46E5),
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
        fontFamily: 'Roboto',
      ),
      home: const AppShell(),
    );
  }
}

class Subject {
  final String name;
  final IconData icon;
  final Color color;
  final List<Topic> topics;

  const Subject({
    required this.name,
    required this.icon,
    required this.color,
    required this.topics,
  });
}

class Topic {
  final String name;
  final String description;
  final List<Lesson> lessons;

  const Topic({
    required this.name,
    required this.description,
    required this.lessons,
  });
}

class Lesson {
  final String title;
  final String explanation;
  final List<String> keyPoints;
  final List<QuizQuestion> quiz;

  const Lesson({
    required this.title,
    required this.explanation,
    required this.keyPoints,
    required this.quiz,
  });
}

class QuizQuestion {
  final String question;
  final List<String> options;
  final int answer;

  const QuizQuestion({
    required this.question,
    required this.options,
    required this.answer,
  });
}

const subjects = <Subject>[
  Subject(
    name: 'Mathematics',
    icon: Icons.calculate_rounded,
    color: Color(0xFF2563EB),
    topics: [
      Topic(
        name: 'Algebra',
        description: 'Understand variables, expressions and equations.',
        lessons: [
          Lesson(
            title: 'Introduction to Variables',
            explanation:
                'A variable is a symbol, usually a letter, that represents a value. Variables allow us to describe unknown quantities and general relationships.',
            keyPoints: [
              'A variable represents a value.',
              'An expression combines numbers, variables and operations.',
              'An equation states that two expressions are equal.',
            ],
            quiz: [
              QuizQuestion(
                question: 'Which symbol is commonly used as a variable?',
                options: ['x', '7', '+', '='],
                answer: 0,
              ),
              QuizQuestion(
                question: 'What does an equation tell us?',
                options: [
                  'Two expressions are equal',
                  'A number is always negative',
                  'There are no variables',
                  'Only addition is allowed'
                ],
                answer: 0,
              ),
            ],
          ),
        ],
      ),
    ],
  ),
  Subject(
    name: 'Physics',
    icon: Icons.bolt_rounded,
    color: Color(0xFF7C3AED),
    topics: [
      Topic(
        name: 'Motion and Forces',
        description: 'Learn how objects move and how forces affect motion.',
        lessons: [
          Lesson(
            title: 'Motion',
            explanation:
                'Motion is a change in position with time. To describe motion, we can use distance, displacement, speed, velocity and acceleration.',
            keyPoints: [
              'Distance is the total path travelled.',
              'Speed tells how quickly distance changes.',
              'Acceleration describes how velocity changes with time.',
            ],
            quiz: [
              QuizQuestion(
                question: 'What is motion?',
                options: [
                  'A change in position with time',
                  'A change in colour',
                  'An object becoming heavier',
                  'A force with no effect'
                ],
                answer: 0,
              ),
              QuizQuestion(
                question: 'Which quantity tells how quickly distance changes?',
                options: ['Mass', 'Speed', 'Force', 'Energy'],
                answer: 1,
              ),
              QuizQuestion(
                question: 'Acceleration describes a change in what?',
                options: ['Mass', 'Volume', 'Velocity', 'Temperature'],
                answer: 2,
              ),
            ],
          ),
        ],
      ),
      Topic(
        name: 'Electricity',
        description: 'Explore charge, current, voltage and circuits.',
        lessons: [
          Lesson(
            title: 'Electric Current',
            explanation:
                'Electric current is the rate at which electric charge flows through a conductor. In simple circuits, a source such as a battery provides the potential difference that drives charge around the circuit.',
            keyPoints: [
              'Current is measured in amperes (A).',
              'Voltage is measured in volts (V).',
              'A complete conducting path is needed for a simple circuit to operate.',
            ],
            quiz: [
              QuizQuestion(
                question: 'What is the SI unit of electric current?',
                options: ['Volt', 'Ampere', 'Ohm', 'Watt'],
                answer: 1,
              ),
              QuizQuestion(
                question: 'What does a battery provide in a simple circuit?',
                options: [
                  'Potential difference',
                  'Only resistance',
                  'No energy',
                  'Mass'
                ],
                answer: 0,
              ),
            ],
          ),
        ],
      ),
    ],
  ),
  Subject(
    name: 'Chemistry',
    icon: Icons.science_rounded,
    color: Color(0xFF059669),
    topics: [
      Topic(
        name: 'Atoms and Elements',
        description: 'Build the foundation of chemistry.',
        lessons: [
          Lesson(
            title: 'The Atom',
            explanation:
                'An atom is the basic unit of an element. It contains a nucleus with protons and neutrons, surrounded by electrons.',
            keyPoints: [
              'Protons have positive charge.',
              'Electrons have negative charge.',
              'Neutrons have no electric charge.',
            ],
            quiz: [
              QuizQuestion(
                question: 'Which particle has a negative charge?',
                options: ['Proton', 'Neutron', 'Electron', 'Nucleus'],
                answer: 2,
              ),
              QuizQuestion(
                question: 'Where are protons found?',
                options: ['In the nucleus', 'Outside the atom only', 'In empty space', 'In the battery'],
                answer: 0,
              ),
            ],
          ),
        ],
      ),
    ],
  ),
  Subject(
    name: 'Biology',
    icon: Icons.biotech_rounded,
    color: Color(0xFFEA580C),
    topics: [
      Topic(
        name: 'Cell Biology',
        description: 'Learn the structure and functions of cells.',
        lessons: [
          Lesson(
            title: 'The Cell',
            explanation:
                'The cell is the basic structural and functional unit of living organisms. Cells contain structures that perform specialised jobs.',
            keyPoints: [
              'The cell membrane controls movement into and out of the cell.',
              'The nucleus contains genetic material in eukaryotic cells.',
              'Mitochondria are involved in energy release.',
            ],
            quiz: [
              QuizQuestion(
                question: 'What is the basic unit of life?',
                options: ['Organ', 'Cell', 'Tissue', 'Atom'],
                answer: 1,
              ),
              QuizQuestion(
                question: 'Which structure controls movement into and out of a cell?',
                options: ['Cell membrane', 'Ribosome', 'Bone', 'Chlorophyll'],
                answer: 0,
              ),
            ],
          ),
        ],
      ),
    ],
  ),
];

class ProgressStore {
  static const xpKey = 'eduvora_xp';
  static const completedKey = 'eduvora_completed';
  static const quizKey = 'eduvora_quiz_scores';

  static Future<int> getXP() async {
    final p = await SharedPreferences.getInstance();
    return p.getInt(xpKey) ?? 0;
  }

  static Future<void> addXP(int amount) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt(xpKey, (p.getInt(xpKey) ?? 0) + amount);
  }

  static Future<Set<String>> getCompleted() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList(completedKey) ?? []).toSet();
  }

  static Future<void> completeLesson(String id) async {
    final p = await SharedPreferences.getInstance();
    final list = p.getStringList(completedKey) ?? [];
    if (!list.contains(id)) list.add(id);
    await p.setStringList(completedKey, list);
  }

  static Future<void> saveQuizScore(String id, int score, int total) async {
    final p = await SharedPreferences.getInstance();
    final map = Map<String, dynamic>.from(
      jsonDecode(p.getString(quizKey) ?? '{}') as Map,
    );
    map[id] = {'score': score, 'total': total};
    await p.setString(quizKey, jsonEncode(map));
  }

  static String levelName(int xp) {
    if (xp >= 1000) return 'Science Master';
    if (xp >= 500) return 'Science Expert';
    if (xp >= 200) return 'Science Explorer';
    return 'Science Beginner';
  }

  static int levelStart(int xp) {
    if (xp >= 1000) return 1000;
    if (xp >= 500) return 500;
    if (xp >= 200) return 200;
    return 0;
  }

  static int nextLevel(int xp) {
    if (xp >= 1000) return 1500;
    if (xp >= 500) return 1000;
    if (xp >= 200) return 500;
    return 200;
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int tab = 0;
  int xp = 0;

  @override
  void initState() {
    super.initState();
    _loadXP();
  }

  Future<void> _loadXP() async {
    final value = await ProgressStore.getXP();
    if (mounted) setState(() => xp = value);
  }

  Future<void> refreshXP() async => _loadXP();

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(xp: xp, onRefresh: refreshXP),
      LearnPage(xp: xp, onRefresh: refreshXP),
      const LabPage(),
      ProfilePage(xp: xp, onRefresh: refreshXP),
    ];

    return Scaffold(
      body: IndexedStack(index: tab, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Learn'),
          NavigationDestination(icon: Icon(Icons.science_outlined), selectedIcon: Icon(Icons.science), label: 'Lab'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final int xp;
  final Future<void> Function() onRefresh;

  const HomePage({super.key, required this.xp, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    final start = ProgressStore.levelStart(xp);
    final next = ProgressStore.nextLevel(xp);
    final progress = ((xp - start) / (next - start)).clamp(0.0, 1.0);

    return SafeArea(
      child: RefreshIndicator(
        onRefresh: onRefresh,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Row(
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Good to see you 👋', style: TextStyle(fontSize: 15, color: Colors.black54)),
                      SizedBox(height: 4),
                      Text('Explore. Experiment. Excel.', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
                CircleAvatar(
                  radius: 24,
                  backgroundColor: Color(0xFFEDE9FE),
                  child: Icon(Icons.school_rounded, color: Color(0xFF4F46E5)),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Card(
              elevation: 0,
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(ProgressStore.levelName(xp), style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('$xp XP', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
                        Text('$next XP to next level', style: const TextStyle(color: Colors.black54)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    LinearProgressIndicator(value: progress, minHeight: 9, borderRadius: BorderRadius.circular(10)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            _SectionTitle(title: 'My Subjects'),
            const SizedBox(height: 10),
            ...subjects.map(
              (s) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _SubjectTile(subject: s),
              ),
            ),
            const SizedBox(height: 8),
            _SectionTitle(title: 'Continue Learning'),
            const SizedBox(height: 10),
            _ContinueCard(
              subject: subjects[1],
              lesson: subjects[1].topics[0].lessons[0],
            ),
            const SizedBox(height: 18),
            _SectionTitle(title: 'Daily Challenge'),
            const SizedBox(height: 10),
            Card(
              elevation: 0,
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.bolt)),
                title: const Text('Earn 20 XP'),
                subtitle: const Text('Complete one lesson today.'),
                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => LessonPage(
                      subject: subjects[1],
                      topic: subjects[1].topics[0],
                      lesson: subjects[1].topics[0].lessons[0],
                      onProgress: onRefresh,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class LearnPage extends StatelessWidget {
  final int xp;
  final Future<void> Function() onRefresh;

  const LearnPage({super.key, required this.xp, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Learn', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text('Choose a subject and learn step by step.', style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 20),
          ...subjects.map(
            (subject) => Card(
              elevation: 0,
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                contentPadding: const EdgeInsets.all(14),
                leading: CircleAvatar(
                  backgroundColor: subject.color.withOpacity(.12),
                  child: Icon(subject.icon, color: subject.color),
                ),
                title: Text(subject.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text('${subject.topics.length} topic${subject.topics.length == 1 ? '' : 's'}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => SubjectPage(subject: subject, onProgress: onRefresh),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SubjectPage extends StatelessWidget {
  final Subject subject;
  final Future<void> Function() onProgress;

  const SubjectPage({super.key, required this.subject, required this.onProgress});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(subject.name)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [subject.color.withOpacity(.95), subject.color.withOpacity(.65)],
              ),
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(subject.icon, color: Colors.white, size: 42),
                const SizedBox(height: 14),
                Text(subject.name, style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800)),
                const SizedBox(height: 5),
                Text('Build your understanding from the ground up.', style: TextStyle(color: Colors.white.withOpacity(.9))),
              ],
            ),
          ),
          const SizedBox(height: 22),
          ...subject.topics.map(
            (topic) => Card(
              elevation: 0,
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                contentPadding: const EdgeInsets.all(16),
                title: Text(topic.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 5),
                  child: Text('${topic.description}\n${topic.lessons.length} lesson${topic.lessons.length == 1 ? '' : 's'}'),
                ),
                isThreeLine: true,
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => TopicPage(subject: subject, topic: topic, onProgress: onProgress),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class TopicPage extends StatelessWidget {
  final Subject subject;
  final Topic topic;
  final Future<void> Function() onProgress;

  const TopicPage({super.key, required this.subject, required this.topic, required this.onProgress});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(topic.name)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(topic.description, style: const TextStyle(fontSize: 17, color: Colors.black54)),
          const SizedBox(height: 20),
          ...List.generate(topic.lessons.length, (i) {
            final lesson = topic.lessons[i];
            return Card(
              elevation: 0,
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                contentPadding: const EdgeInsets.all(16),
                leading: CircleAvatar(child: Text('${i + 1}')),
                title: Text(lesson.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: const Padding(
                  padding: EdgeInsets.only(top: 5),
                  child: Text('Lesson + quiz • earn XP'),
                ),
                trailing: const Icon(Icons.play_arrow_rounded),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => LessonPage(
                      subject: subject,
                      topic: topic,
                      lesson: lesson,
                      onProgress: onProgress,
                    ),
                  ),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}

class LessonPage extends StatelessWidget {
  final Subject subject;
  final Topic topic;
  final Lesson lesson;
  final Future<void> Function() onProgress;

  const LessonPage({
    super.key,
    required this.subject,
    required this.topic,
    required this.lesson,
    required this.onProgress,
  });

  String get id => '${subject.name}|${topic.name}|${lesson.title}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lesson')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(subject.name, style: TextStyle(color: subject.color, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Text(lesson.title, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
          const SizedBox(height: 20),
          Card(
            elevation: 0,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Text(lesson.explanation, style: const TextStyle(fontSize: 17, height: 1.55)),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Key Points', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          ...lesson.keyPoints.map(
            (point) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.check_circle_rounded, size: 21, color: Color(0xFF10B981)),
                  const SizedBox(width: 10),
                  Expanded(child: Text(point, style: const TextStyle(fontSize: 16))),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton.icon(
            icon: const Icon(Icons.quiz_rounded),
            label: const Text('Take Quiz'),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => QuizPage(
                  lesson: lesson,
                  lessonId: id,
                  onProgress: onProgress,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class QuizPage extends StatefulWidget {
  final Lesson lesson;
  final String lessonId;
  final Future<void> Function() onProgress;

  const QuizPage({
    super.key,
    required this.lesson,
    required this.lessonId,
    required this.onProgress,
  });

  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int index = 0;
  int score = 0;
  int? selected;
  bool answered = false;

  void choose(int option) {
    if (answered) return;
    setState(() {
      selected = option;
      answered = true;
      if (option == widget.lesson.quiz[index].answer) score++;
    });
  }

  Future<void> next() async {
    if (!answered) return;
    if (index < widget.lesson.quiz.length - 1) {
      setState(() {
        index++;
        selected = null;
        answered = false;
      });
    } else {
      final earned = 10 + score * 5;
      await ProgressStore.addXP(earned);
      await ProgressStore.completeLesson(widget.lessonId);
      await ProgressStore.saveQuizScore(widget.lessonId, score, widget.lesson.quiz.length);
      await widget.onProgress();
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => QuizResultPage(
            score: score,
            total: widget.lesson.quiz.length,
            earnedXP: earned,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.lesson.quiz[index];
    return Scaffold(
      appBar: AppBar(title: Text('Quiz ${index + 1}/${widget.lesson.quiz.length}')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          LinearProgressIndicator(value: (index + 1) / widget.lesson.quiz.length, minHeight: 8),
          const SizedBox(height: 26),
          Text(q.question, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, height: 1.25)),
          const SizedBox(height: 22),
          ...List.generate(q.options.length, (i) {
            final isCorrect = i == q.answer;
            final isSelected = i == selected;
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () => choose(i),
                child: Container(
                  padding: const EdgeInsets.all(17),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      width: 1.4,
                      color: answered && isCorrect
                          ? Colors.green
                          : answered && isSelected
                              ? Colors.red
                              : Colors.black12,
                    ),
                    color: answered && isCorrect
                        ? Colors.green.withOpacity(.08)
                        : answered && isSelected
                            ? Colors.red.withOpacity(.08)
                            : Colors.white,
                  ),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 16,
                        child: Text(String.fromCharCode(65 + i)),
                      ),
                      const SizedBox(width: 12),
                      Expanded(child: Text(q.options[i], style: const TextStyle(fontSize: 16))),
                    ],
                  ),
                ),
              ),
            );
          }),
          const SizedBox(height: 12),
          if (answered)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text(
                selected == q.answer ? 'Correct! 🎉' : 'Not quite. Review the correct option.',
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: selected == q.answer ? Colors.green : Colors.red,
                ),
              ),
            ),
          FilledButton(
            onPressed: answered ? next : null,
            child: Text(index == widget.lesson.quiz.length - 1 ? 'Finish Quiz' : 'Next Question'),
          ),
        ],
      ),
    );
  }
}

class QuizResultPage extends StatelessWidget {
  final int score;
  final int total;
  final int earnedXP;

  const QuizResultPage({
    super.key,
    required this.score,
    required this.total,
    required this.earnedXP,
  });

  @override
  Widget build(BuildContext context) {
    final percent = ((score / total) * 100).round();
    return Scaffold(
      appBar: AppBar(title: const Text('Quiz Result')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircleAvatar(
                radius: 44,
                child: Icon(Icons.emoji_events_rounded, size: 46),
              ),
              const SizedBox(height: 20),
              const Text('Great work!', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text('$score / $total correct • $percent%', style: const TextStyle(fontSize: 19)),
              const SizedBox(height: 12),
              Text('+$earnedXP XP earned', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
              const SizedBox(height: 30),
              FilledButton(
                onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
                child: const Text('Back to Eduvora'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LabPage extends StatelessWidget {
  const LabPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Virtual Lab', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          const Text('Experiment safely and learn by doing.', style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 20),
          _LabCard(
            icon: Icons.speed_rounded,
            title: 'Motion Explorer',
            description: 'Explore distance, time and speed with an interactive simulation.',
          ),
          _LabCard(
            icon: Icons.electrical_services_rounded,
            title: 'Circuit Builder',
            description: 'Learn how batteries, switches and bulbs work together.',
          ),
          _LabCard(
            icon: Icons.science_rounded,
            title: 'Atom Explorer',
            description: 'Explore protons, neutrons and electrons.',
          ),
        ],
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  final int xp;
  final Future<void> Function() onRefresh;

  const ProfilePage({super.key, required this.xp, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    final level = ProgressStore.levelName(xp);
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Profile', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
          const SizedBox(height: 20),
          Card(
            elevation: 0,
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                children: [
                  const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 44)),
                  const SizedBox(height: 12),
                  Text(level, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                  Text('$xp XP', style: const TextStyle(color: Colors.black54)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            elevation: 0,
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.emoji_events_outlined),
                  title: const Text('Achievements'),
                  subtitle: const Text('Keep learning to unlock achievements.'),
                  trailing: const Icon(Icons.chevron_right),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.refresh_rounded),
                  title: const Text('Refresh progress'),
                  onTap: onRefresh,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800));
  }
}

class _SubjectTile extends StatelessWidget {
  final Subject subject;
  const _SubjectTile({required this.subject});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 6),
        leading: CircleAvatar(
          backgroundColor: subject.color.withOpacity(.12),
          child: Icon(subject.icon, color: subject.color),
        ),
        title: Text(subject.name, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text('${subject.topics.length} topic${subject.topics.length == 1 ? '' : 's'}'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => SubjectPage(subject: subject, onProgress: () async {}),
          ),
        ),
      ),
    );
  }
}

class _ContinueCard extends StatelessWidget {
  final Subject subject;
  final Lesson lesson;

  const _ContinueCard({required this.subject, required this.lesson});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(17),
        child: Row(
          children: [
            CircleAvatar(
              radius: 26,
              backgroundColor: subject.color.withOpacity(.12),
              child: Icon(subject.icon, color: subject.color),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(subject.name, style: TextStyle(color: subject.color, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text(lesson.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  const Text('Lesson + quiz', style: TextStyle(color: Colors.black54)),
                ],
              ),
            ),
            IconButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => LessonPage(
                    subject: subject,
                    topic: subject.topics[0],
                    lesson: lesson,
                    onProgress: () async {},
                  ),
                ),
              ),
              icon: const Icon(Icons.play_circle_fill_rounded),
            ),
          ],
        ),
      ),
    );
  }
}

class _LabCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;

  const _LabCard({required this.icon, required this.title, required this.description});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        contentPadding: const EdgeInsets.all(17),
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Text(description),
        ),
        isThreeLine: true,
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}
