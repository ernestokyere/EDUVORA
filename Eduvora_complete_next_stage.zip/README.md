# Eduvora

This is the next working build of the Eduvora learning app.

Included:
- Home dashboard
- Mathematics, Physics, Chemistry and Biology
- Subject -> Topic -> Lesson -> Quiz flow
- Quiz scoring
- XP rewards
- Science Beginner / Explorer / Expert / Master progression
- Local progress persistence with SharedPreferences
- Profile
- Virtual Lab starter screen
- Material 3 responsive UI

## Run
1. Extract the ZIP.
2. Open the folder as the Flutter project.
3. Run:
   flutter pub get
   flutter run

The app currently stores XP and completion locally. Supabase persistence can be connected in the next stage.
